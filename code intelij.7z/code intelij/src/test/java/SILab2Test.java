import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SILab2Test {


    List<Angle> createList(Angle... element){
        return new ArrayList<Angle>(Arrays.asList(element));
    }
    @Test
    void everyStatementTest(){
        RuntimeException ex;
        Angle angle = new Angle(40,60,20);
        ex=assertThrows(RuntimeException.class,()->SILab2.function(createList(angle)));
        assertTrue(ex.getMessage().contains("The minutes of the angle are not valid!"));

        Angle angl2 = new Angle(40,40,60);
        ex=assertThrows(RuntimeException.class,()->SILab2.function(createList(angl2)));
        assertTrue(ex.getMessage().contains("The seconds of the angle are not valid"));

        Angle angl3 = new Angle(40,40,50);
        List<Integer> nova2 = SILab2.function(createList(angl3));
//        int indeks1 = nova2.get(0);
        //assertEquals(146450,indeks1);
        for (Integer x: nova2){
            assertEquals(146450, x);
        }

                Angle angl4 = new Angle(360,0,0);
        List<Integer> nova = SILab2.function(createList(angl4));
//        int indeks2 = nova.get(0);
//            assertEquals(1296000,indeks2);
        for (Integer x: nova){
            assertEquals(1296000, x);
        }


        Angle angle5 = new Angle(360,20,30);
        ex=assertThrows(RuntimeException.class,()->SILab2.function(createList(angle5)));
        assertTrue(ex.getMessage().contains("The angle is greater then the maximum"));

        Angle angl6 = new Angle(380,20,30);
        ex=assertThrows(RuntimeException.class,()->SILab2.function(createList(angl6)));
        assertTrue(ex.getMessage().contains("The angle is smaller or greater then the minimum"));
    }

    @Test
    void MultipleCondititon(){
//        if (deg >= 0 && deg < 360)
//        T && T
//        T && F
//        F && T
//        if (min < 0 || min > 59)
//        T || F
//        F || T
//        F || F
        RuntimeException ex;
        Angle angle = new Angle(40,-1,20);
        ex=assertThrows(RuntimeException.class,()->SILab2.function(createList(angle)));
        assertTrue(ex.getMessage().contains("The minutes of the angle are not valid!"));

        Angle angl2 = new Angle(40,60,20);
        ex=assertThrows(RuntimeException.class,()->SILab2.function(createList(angl2)));
        assertTrue(ex.getMessage().contains("The minutes of the angle are not valid!"));

        //        if (sec < 0 || sec > 59)
//        T || F
//        F || T
//        F || F
        Angle angl3 = new Angle(40,50,-5);
        ex=assertThrows(RuntimeException.class,()->SILab2.function(createList(angl3)));
        assertTrue(ex.getMessage().contains("The seconds of the angle are not valid"));

        Angle angl4 = new Angle(40,50,60);
        ex=assertThrows(RuntimeException.class,()->SILab2.function(createList(angl4)));
        assertTrue(ex.getMessage().contains("The seconds of the angle are not valid"));


//        if (min == 0 && sec == 0)
//        T && T
//        T && F
//        F && T

        Angle angl5 = new Angle(360,0,0);
        List<Integer> nova = SILab2.function(createList(angl5));
        for (Integer x: nova){
            assertEquals(1296000, x);
        }

        Angle angl6 = new Angle(360,0,5);
        ex=assertThrows(RuntimeException.class,()->SILab2.function(createList(angl6)));
        assertTrue(ex.getMessage().contains("The angle is greater then the maximum"));

        Angle angl7 = new Angle(360,10,0);
        ex=assertThrows(RuntimeException.class,()->SILab2.function(createList(angl7)));
        assertTrue(ex.getMessage().contains("The angle is greater then the maximum"));
    }

}